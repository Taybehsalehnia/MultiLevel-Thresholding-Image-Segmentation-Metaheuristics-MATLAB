function [ fit ] = fitnessfunction1(Positioni, Histogram, Thresh_number)

%==============================
% Safe & Corrected Fitness Function
%==============================

Positioni = abs(Positioni);
Positioni = floor(Positioni);
Positioni = sort(Positioni);

L = length(Histogram);   % normally 256

% --- Clamp thresholds to valid range [1 , 255] ---
Positioni(Positioni < 1)   = 1;
Positioni(Positioni > 255) = 255;

%==============================
% Global Mean (lambda)
%==============================
levels = 0:L-1;
landa1 = sum(levels .* Histogram');

%==============================
% Class Probabilities Ai
%==============================
for i = 0:Thresh_number
    if i == 0
        idx1 = 1;
        idx2 = Positioni(1);
    elseif i > 0 && i < Thresh_number
        idx1 = Positioni(i) + 1;
        idx2 = Positioni(i+1);
    else
        idx1 = Positioni(i) + 1;
        idx2 = L;
    end

    % --- Safety clamp ---
    idx1 = max(1, min(idx1, L));
    idx2 = max(1, min(idx2, L));

    if idx2 >= idx1
        Ai(i+1) = sum(Histogram(idx1:idx2));
    else
        Ai(i+1) = eps;
    end
end

%==============================
% Class Means landai
%==============================
for i = 0:Thresh_number
    if i == 0
        idx1 = 1;
        idx2 = Positioni(1);
    elseif i > 0 && i < Thresh_number
        idx1 = Positioni(i) + 1;
        idx2 = Positioni(i+1);
    else
        idx1 = Positioni(i) + 1;
        idx2 = L;
    end

    % --- Safety clamp ---
    idx1 = max(1, min(idx1, L));
    idx2 = max(1, min(idx2, L));

    if idx2 >= idx1
        num = sum(levels(idx1:idx2) .* Histogram(idx1:idx2)');
        den = sum(Histogram(idx1:idx2)) + eps;
        landai(i+1) = num / den;
    else
        landai(i+1) = 0;
    end
end

%==============================
% Final Fitness (Otsu Between-Class Variance Style)
%==============================
fit = 1 / (sum(Ai .* ((landai - landa1).^2)) + eps);

end
