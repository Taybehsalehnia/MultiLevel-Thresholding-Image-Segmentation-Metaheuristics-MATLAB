function [Best_Fit, Best_Thresh, Segment_im, BestCost, AllFitness] = AWOA_Segmentation(Histogram, im, Thresh_number, Class_number, N, Max_iter, dim, VarMax, VarMin, lb, ub)
% AWOA_Segmentation
% Hybrid A(WOA+AO) for Multilevel Image Thresholding with Two-Stage Fitness
% Inputs:
%   Histogram      - normalized histogram (length 256) of image (probabilities)
%   im             - original image (double)
%   Thresh_number  - K (number of thresholds)
%   Class_number   - K+1
%   N              - population size (number of agents)
%   Max_iter       - number of iterations
%   dim            - dimensionality (should equal Thresh_number)
%   VarMax         - maximum gray-level (typically 255 or max(im))
%   VarMin         - minimum gray-level (typically 1)
%   lb, ub         - lower/upper bounds (scalars or vectors)
%
% Outputs:
%   Best_Fit       - final combined fitness (after stage2) (higher is better)
%   Best_Thresh    - K thresholds (sorted, integer)
%   Segment_im     - segmented image using Best_Thresh (double)
%   BestCost       - array (Max_iter x 1) best Otsu cost (we store best Otsu objective at each iteration)
%   AllFitness     - (Max_iter x N) Otsu fitness values of population at each iteration
%
% Notes:
%   - This implementation follows the described AWOA structure: AOS mixing AO and WOA,
%     dual-populations, OBL, elite archive, memetic local search, two-stage fitness.
%   - For Stage1 we use Otsu between-class variance as objective (to be maximized).
%   - For Stage2 we refine the top M candidates using combined normalized Otsu/PSNR/SSIM.
%
% Author: Generated per user specification (Taybeh Salehnia style)
% Date: (auto)

% -------------------- parameters (tunable) --------------------
M_top = 10;            % number of top solutions from stage1 to refine
E_rate = 0.05;         % elite archive fraction
tau_m = 10;            % migration interval (iterations)
m_mig = max(1,round(N/10)); % number of migrants
gamma1 = 0.7; gamma2 = 0.3; % AOS coefficients
eta_memetic = 0.01 * VarMax; % memetic local search step-size
OBL_on_init = true;    % apply Opposition-based learning at initialization
% AO/WOA parameters (use reasonable defaults)
AO_alpha = 0.1; AO_delta = 0.1; % from AO code
% -------------------- derived --------------------
Dim = dim;
if isscalar(lb), lb = lb * ones(1,Dim); end
if isscalar(ub), ub = ub * ones(1,Dim); end

% Prepare outputs
BestCost = inf(Max_iter,1);
AllFitness = nan(Max_iter, N);

% -------------------- Initialization --------------------
% Initialize two subpopulations
N_A = floor(N/2);
N_W = N - N_A;

% Initialize positions uniformly in [lb,ub]
Positions = zeros(N,Dim);
for j=1:Dim
    Positions(:,j) = unifrnd(lb(j), ub(j), [N,1]);
end

% sort thresholds per agent and clip
for i=1:N
    Positions(i,:) = sort(Positions(i,:));
end

% Opposition-Based Learning (OBL) for initial population
if OBL_on_init
    Opp = repmat(lb,N,1) + repmat(ub,N,1) - Positions;
    % evaluate OBL candidates using Otsu; keep better
    for i=1:N
        fitP = otsu_obj(Positions(i,:), Histogram, Thresh_number);
        fitO = otsu_obj(Opp(i,:), Histogram, Thresh_number);
        if fitO > fitP
            Positions(i,:) = Opp(i,:);
        end
    end
end

% Evaluate initial population (Otsu objective)
OtsuVals = zeros(N,1);
for i=1:N
    OtsuVals(i) = otsu_obj(Positions(i,:), Histogram, Thresh_number);
end

% Setup Elite Archive
E = max(1, round(E_rate * N));
[~, idxs] = sort(OtsuVals,'descend'); % Otsu maximize
Archive.Pos = Positions(idxs(1:E),:);
Archive.Val = OtsuVals(idxs(1:E));

% initialize best
[BestOtsu, bestIdx] = max(OtsuVals);
BestPos = Positions(bestIdx,:);
BestOtsu_history = BestOtsu;
BestCost(1) = BestOtsu;
AllFitness(1,:) = OtsuVals';

% Variables for AOS
prev_best = BestOtsu;
Divert_hist = zeros(Max_iter,1);
IR_hist = zeros(Max_iter,1);

% -------------------- Main Loop (Stage 1) --------------------
for it = 1:Max_iter
    % compute diversity index Divert(t)
    std_per_dim = std(Positions,0,1); % 1xDim
    Divert = mean(std_per_dim) / max(1e-9,(max(ub)-min(lb))); % normalized approx [0,1]
    Divert_hist(it) = Divert;
    
    % improvement rate IR(t)
    if it==1
        IR = 0;
    else
        IR = (BestOtsu - prev_best) / (abs(prev_best) + eps);
    end
    IR_hist(it) = IR;
    prev_best = BestOtsu;
    
    % compute operator weights via sigmoid-ish linear scaling
    P_AO = sigmoid(gamma1*Divert - gamma2*IR);
    P_WOA = 1 - P_AO;
    
    % split into subpopulations (we keep indices)
    idx_perm = randperm(N);
    idx_A = idx_perm(1:N_A);
    idx_W = idx_perm(N_A+1:end);
    
    % For each agent decide operator based on P_AO (stochastic)
    for i=1:N
        if rand() < P_AO
            % Apply AO operator (Aquila) - simplified & adapted
            % Use behavior switching based on iteration progress
            X = Positions(i,:);
            t = it; T = Max_iter;
            if t <= (2/3)*T
                if rand < 0.5
                    Xnew = BestPos*(1-t/T) + (mean(Positions,1)-BestPos).*rand(1,Dim);
                else
                    Xnew = BestPos .* levy_flight(Dim) + Positions(randi(N),:) + (rand(1,Dim)-0.5).*(ub-lb);
                end
            else
                if rand < 0.5
                    Xnew = (BestPos - mean(Positions,1))*AO_alpha - rand(1,Dim) + ((ub-lb).*rand(1,Dim)+lb)*AO_delta;
                else
                    G2 = 2*rand()-1; G1 = 2*(1-(t/T));
                    QF = t^((2*rand()-1)/(1-T)^2 + eps);
                    Xnew = QF*BestPos - (G2*X).*rand(1,Dim) - G1.*levy_flight(Dim) + rand(1,Dim).*G2;
                end
            end
        else
            % Apply WOA operator (Whale) - simplified & adapted
            a = 2 - it*((2)/Max_iter);
            r1 = rand(1,Dim); r2 = rand(1,Dim);
            A = 2*a.*r1 - a;
            C = 2.*r2;
            p = rand();
            b = 1;
            l = ( -1 + it*((-1)/Max_iter) - 1 )*rand() + 1; % approximate from template
            X = Positions(i,:);
            if p < 0.5
                if abs(A(1)) >= 1
                    rand_idx = randi(N);
                    X_rand = Positions(rand_idx,:);
                    D_X_rand = abs(C .* X_rand - X);
                    Xnew = X_rand - A .* D_X_rand;
                else
                    D_Leader = abs(C .* BestPos - X);
                    Xnew = BestPos - A .* D_Leader;
                end
            else
                distance2Leader = abs(BestPos - X);
                Xnew = distance2Leader .* exp(b.*l) .* cos(l*2*pi) + BestPos;
            end
        end
        
        % boundary control & sort
        Xnew = max(min(Xnew,ub),lb);
        Xnew = sort(Xnew);
        
        % compute Otsu fitness for new position
        newFit = otsu_obj(Xnew, Histogram, Thresh_number);
        % greedy replacement
        if newFit > OtsuVals(i)
            Positions(i,:) = Xnew;
            OtsuVals(i) = newFit;
        end
    end
    
    % Archive update (keep top E solutions)
    [sortedVals, sIdx] = sort(OtsuVals,'descend');
    Archive.Pos = Positions(sIdx(1:E),:);
    Archive.Val = sortedVals(1:E);
    
    % Mutual migration every tau_m iterations
    if mod(it, tau_m) == 0
        % select m_mig random from each half and swap
        A_idx = sIdx(1:m_mig);
        W_idx = sIdx(end-m_mig+1:end);
        tmp = Positions(A_idx,:);
        Positions(A_idx,:) = Positions(W_idx,:);
        Positions(W_idx,:) = tmp;
        % re-evaluate OtsuVals for swapped (safe)
        for ii = [A_idx, W_idx]
            OtsuVals(ii) = otsu_obj(Positions(ii,:), Histogram, Thresh_number);
        end
    end
    
    % Memetic local search on top k individuals (greedy gaussian)
    k_mem = max(1, round(0.02*N)); % e.g., top 2% each iter
    topk_idx = sIdx(1:k_mem);
    for idx = topk_idx'
        Xold = Positions(idx,:);
        Xcand = Xold + eta_memetic * randn(1,Dim);
        Xcand = max(min(Xcand,ub),lb);
        Xcand = sort(Xcand);
        fc = otsu_obj(Xcand, Histogram, Thresh_number);
        if fc > OtsuVals(idx)
            Positions(idx,:) = Xcand;
            OtsuVals(idx) = fc;
        end
    end
    
    % Update best
    [currentBest, bi] = max(OtsuVals);
    BestPos = Positions(bi,:);
    BestOtsu = currentBest;
    BestCost(it) = BestOtsu;
    AllFitness(it,:) = OtsuVals';
    
    % store progress display occasionally
    % (commented to avoid clutter; uncomment if desired)
    % if mod(it,10)==0
    %     disp(['Iter ' num2str(it) ' Best Otsu = ' num2str(BestOtsu)]);
    % end
end % end Stage1 iterations

% -------------------- Stage1: select M_top candidates --------------------
[sortedFinalVals, finalIdx] = sort(AllFitness(end,:),'descend');
% But better to sort using last OtsuVals
[sortedValsEnd, sIdxEnd] = sort(OtsuVals,'descend');
M_act = min(M_top, N);
TopCandidates = Positions(sIdxEnd(1:M_act),:);
TopOtsuVals = OtsuVals(sIdxEnd(1:M_act));

% -------------------- Stage2: Perceptual Refinement --------------------
% For stage2 we'll do local search around each of the M candidates and compute combined fitness:
% Fitness(T) = w1*norm(Otsu) + w2*norm(PSNR) + w3*norm(SSIM)
w1 = 0.4; w2 = 0.3; w3 = 0.3;

% Pre-allocate arrays to store metric ranges for normalization
numCandidates = size(TopCandidates,1);
AllStage2.Otsu = zeros(numCandidates,1);
AllStage2.PSNR = zeros(numCandidates,1);
AllStage2.SSIM = zeros(numCandidates,1);
AllStage2.Pos = zeros(numCandidates,Dim);

% We'll evaluate each candidate and run a small memetic refinement loop for each
refine_iters = 30; % local refinement iterations per candidate (tunable)
for cidx = 1:numCandidates
    X = TopCandidates(cidx,:);
    % do small greedy local search
    bestX = X;
    % evaluate metrics for current
    [otsu_v, seg_im] = otsu_obj_and_segment(bestX, Histogram, im, Thresh_number, Class_number, VarMax);
    psnr_v = compute_psnr(im, seg_im);
    ssim_v = compute_ssim(im, seg_im);
    best_metrics = [otsu_v, psnr_v, ssim_v];
    
    % local refinement loop: gaussian perturbations
    for r = 1:refine_iters
        step = 0.02 * VarMax; % small
        Xcand = bestX + step * randn(1,Dim);
        Xcand = max(min(Xcand,ub),lb);
        Xcand = sort(Xcand);
        [otsu_c, seg_c] = otsu_obj_and_segment(Xcand, Histogram, im, Thresh_number, Class_number, VarMax);
        psnr_c = compute_psnr(im, seg_c);
        ssim_c = compute_ssim(im, seg_c);
        % Combine using temporary normalization across current candidate evaluations:
        % We'll store raw metrics and normalize at the end across all candidates+their trials.
        % For simplicity here we use greedy acceptance if combined raw weighted (after scaling heuristics)
        % but better to record and normalize later � so store all for final normalization.
        % Keep best by simple surrogate: prefer higher (otsu + 0.01*psnr + ssim*10) as proxy
        proxy_old = best_metrics(1) + 0.01*best_metrics(2) + 10*best_metrics(3);
        proxy_new = otsu_c + 0.01*psnr_c + 10*ssim_c;
        if proxy_new > proxy_old
            bestX = Xcand;
            best_metrics = [otsu_c, psnr_c, ssim_c];
        end
    end
    AllStage2.Otsu(cidx) = best_metrics(1);
    AllStage2.PSNR(cidx) = best_metrics(2);
    AllStage2.SSIM(cidx) = best_metrics(3);
    AllStage2.Pos(cidx,:) = bestX;
end

% Normalize metrics across the candidates to [0,1]
% to prevent zero range, add eps
otsu_min = min(AllStage2.Otsu); otsu_max = max(AllStage2.Otsu);
psnr_min = min(AllStage2.PSNR); psnr_max = max(AllStage2.PSNR);
ssim_min = min(AllStage2.SSIM); ssim_max = max(AllStage2.SSIM);

norm_otsu = (AllStage2.Otsu - otsu_min) ./ ( (otsu_max - otsu_min) + eps );
norm_psnr = (AllStage2.PSNR - psnr_min) ./ ( (psnr_max - psnr_min) + eps );
norm_ssim = (AllStage2.SSIM - ssim_min) ./ ( (ssim_max - ssim_min) + eps );

Combined = w1.*norm_otsu + w2.*norm_psnr + w3.*norm_ssim;

% choose best candidate after stage2
[bestVal2, idx2] = max(Combined);
Best_Thresh_raw = AllStage2.Pos(idx2,:);
Best_Thresh = floor(sort(Best_Thresh_raw));
Best_Fit = bestVal2;

% build segmented image with Best_Thresh
Segment_im = segment_with_thresholds(im, Best_Thresh, Class_number, VarMax);

% return BestCost and AllFitness (AllFitness may have NaNs for remaining iterations if any)
% If any AllFitness rows are NaN (due to not assigned), fill last row with current OtsuVals
nanrows = any(isnan(AllFitness'),1);
if any(nanrows)
    AllFitness(find(any(isnan(AllFitness),2),1):end,:) = repmat(OtsuVals', sum(nanrows),1);
end

end

% -------------------- Helper subfunctions --------------------

function y = sigmoid(x)
    y = 1./(1+exp(-10*(x-0.5))); % steeper sigmoid mapping to (0,1)
end

function s = levy_flight(d)
    beta = 1.5;
    sigma = (gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
    u = randn(1,d) * sigma; v = randn(1,d);
    step = u ./ (abs(v).^(1/beta) + eps);
    s = step;
end

% -------------------- ???????: ???? otsu_obj --------------------
% -------------------- ?????????: ???? otsu_obj --------------------
function val = otsu_obj(Position, Histogram, K)
    % Ensure Position is a 1xK row vector
    Position = Position(:)';         % force row
    pos = floor(sort(abs(Position)));% sorted row vector
    pos = max(0, min(255, pos));     % clamp to [0,255]
    P = Histogram(:)';               % 1x256

    % Build edges so that classes are:
    % class1: 0 .. pos(1)-1
    % class2: pos(1) .. pos(2)-1
    % ...
    % last: pos(end) .. 255
    edges = [0, pos, 256];  % now pos is row -> concatenation safe
    C = length(edges)-1;
    w = zeros(1,C);
    mu_k = zeros(1,C);

    for k = 1:C
        a = edges(k);
        b = edges(k+1)-1;
        if a > b
            idx = [];   % empty range
        else
            % map intensity a..b to histogram indices (1..256)
            idx = (a:b) + 1;
            % ensure idx inside 1..256
            idx(idx<1) = [];
            idx(idx>256) = [];
        end
        if isempty(idx)
            w(k) = 0;
            mu_k(k) = 0;
        else
            w(k) = sum(P(idx));
            if w(k) > 0
                levels = (idx-1); % 0..255
                mu_k(k) = sum(levels .* P(idx)) / (w(k) + eps);
            else
                mu_k(k) = 0;
            end
        end
    end

    mu_T = sum((0:255) .* P);
    val = sum(w .* (mu_k - mu_T).^2);
    val = max(0, val); % numerical safety
end

% -------------------- ?????????: otsu_obj_and_segment --------------------
function [otsu_v, seg_im] = otsu_obj_and_segment(Position, Histogram, im, K, Class_number, VarMax)
    Position = Position(:)';                 % ensure row
    pos = floor(sort(abs(Position)));
    pos = max(0, min(255, pos));
    otsu_v = otsu_obj(pos, Histogram, K);
    seg_im = segment_with_thresholds(im, pos, Class_number, VarMax);
end

% -------------------- ?????????: segment_with_thresholds --------------------
function seg = segment_with_thresholds(im, Thresh, Class_number, VarMax)
    % Thresh must be 1xK row vector (integers between 0..255)
    Thresh = Thresh(:)'; % force row
    Thresh = floor(sort(abs(Thresh)));
    Thresh = max(0, min(255, Thresh));
    seg = zeros(size(im));
    K = length(Thresh);
    edges = [0, Thresh, 256];
    for iClass = 1:Class_number
        a = edges(iClass);
        b = edges(iClass+1)-1;
        if a > b
            mask = false(size(im));
        else
            mask = (im >= a) & (im <= b);
        end
        if any(mask(:))
            seg(mask) = mean(im(mask));
        end
    end
    % fill any remaining zeros with original image values (safety)
    zero_idx = (seg == 0);
    if any(zero_idx(:))
        seg(zero_idx) = im(zero_idx);
    end
end


function ps = compute_psnr(orig, seg)
    % orig and seg are double with values in [0,255]
    mse = mean((orig(:)-seg(:)).^2);
    if mse <= 0
        ps = 100;
    else
        ps = 10*log10(255^2 / mse);
    end
end

function s = compute_ssim(orig, seg)
    % use MATLAB's ssim if available; otherwise simple fallback
    try
        s = ssim(uint8(seg), uint8(orig), 'RegularizationConstants',[6.5025,58.52252,29.2613]);
        s = abs(s);
    catch
        % fallback (naive): normalized cross-correlation based approx
        mu1 = mean(orig(:)); mu2 = mean(seg(:));
        sigma1 = std(orig(:)); sigma2 = std(seg(:));
        cov12 = mean((orig(:)-mu1).*(seg(:)-mu2));
        c1 = 6.5025; c2 = 58.52252;
        s = ((2*mu1*mu2 + c1)*(2*cov12 + c2)) / ((mu1^2 + mu2^2 + c1)*(sigma1^2 + sigma2^2 + c2) + eps);
        s = max(0,min(1,s));
    end
end
