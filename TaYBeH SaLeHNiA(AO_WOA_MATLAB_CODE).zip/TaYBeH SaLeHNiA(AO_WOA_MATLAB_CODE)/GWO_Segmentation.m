function [Best_Fit, Best_Thresh, Segment_im] = GWO_Segmentation( ...
    Histogram, im, Thresh_number, Class_number, ...
    SearchAgents_no, Max_iter, dim, CMax, CMin, lb, ub)

%====================================================
%     Grey Wolf Optimizer for Image Segmentation
%====================================================

%==============================
%-------Initialization---------
%==============================
Alpha_pos = zeros(1,dim);
Alpha_score = inf;

Beta_pos = zeros(1,dim);
Beta_score = inf;

Delta_pos = zeros(1,dim);
Delta_score = inf;

Boundary_no = size(ub,2);

% Initialize Positions
if Boundary_no == 1
    Positions = rand(SearchAgents_no,dim).*(ub-lb)+lb;
else
    Positions = zeros(SearchAgents_no,dim);
    for i=1:dim
        Positions(:,i) = rand(SearchAgents_no,1).*(ub(i)-lb(i))+lb(i);
    end
end

Convergence_curve = zeros(1,Max_iter);
l = 0;

%==============================
%---------- GWO Loop ----------
%==============================
while l < Max_iter

    for i = 1:size(Positions,1)

        % Boundary Control
        Flag4ub = Positions(i,:) > ub;
        Flag4lb = Positions(i,:) < lb;
        Positions(i,:) = (Positions(i,:).*(~(Flag4ub+Flag4lb))) ...
                         + ub.*Flag4ub + lb.*Flag4lb;

        % Fitness Evaluation
        fitness = fitnessfunction(Positions(i,:), Histogram, Thresh_number);

        % Update Alpha, Beta, Delta
        if fitness < Alpha_score
            Alpha_score = fitness;
            Alpha_pos = Positions(i,:);
        end

        if fitness > Alpha_score && fitness < Beta_score
            Beta_score = fitness;
            Beta_pos = Positions(i,:);
        end

        if fitness > Alpha_score && fitness > Beta_score && fitness < Delta_score
            Delta_score = fitness;
            Delta_pos = Positions(i,:);
        end
    end

    a = 2 - l * (2 / Max_iter);

    % Position Update
    for i = 1:size(Positions,1)
        for j = 1:size(Positions,2)

            r1 = rand(); r2 = rand();
            A1 = 2*a*r1 - a;
            C1 = 2*r2;
            D_alpha = abs(C1*Alpha_pos(j) - Positions(i,j));
            X1 = Alpha_pos(j) - A1*D_alpha;

            r1 = rand(); r2 = rand();
            A2 = 2*a*r1 - a;
            C2 = 2*r2;
            D_beta = abs(C2*Beta_pos(j) - Positions(i,j));
            X2 = Beta_pos(j) - A2*D_beta;

            r1 = rand(); r2 = rand();
            A3 = 2*a*r1 - a;
            C3 = 2*r2;
            D_delta = abs(C3*Delta_pos(j) - Positions(i,j));
            X3 = Delta_pos(j) - A3*D_delta;

            Positions(i,j) = (X1 + X2 + X3) / 3;
        end
    end

    l = l + 1;
    Convergence_curve(l) = Alpha_score;
end

%==============================
%--------- Final Outputs ------
%==============================

Best_Fit    = 1 / Alpha_score;
Best_Thresh = Alpha_pos;
Best_Thresh = floor(sort(Best_Thresh));

%==============================
%---- Image Segmentation ------
%==============================
Segment_im = zeros(size(im));

for i = 1:Class_number
    if i == 1
        idx = find(im <= (Best_Thresh(i)-1) & im >= 0);
        Segment_im(idx) = mean(im(idx));

    elseif i > 1 && i < Class_number
        idx = find(im <= (Best_Thresh(i)-1) & im >= Best_Thresh(i-1));
        Segment_im(idx) = mean(im(idx));

    elseif i == Class_number
        idx = find(im <= CMax & im >= Best_Thresh(i-1));
        Segment_im(idx) = mean(im(idx));
    end
end

end
