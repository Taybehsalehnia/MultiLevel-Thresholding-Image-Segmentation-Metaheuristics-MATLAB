function [Best_Fit, Best_Thresh, Segment_im] = HHO_Segmentation(Histogram, im, Thresh_number, Class_number, N, maxLoop, varNum, CMax, CMin, lowerBound,upperBound)

%==============================
%-------Initialization---------
%==============================
% initialize position vector and score for the leader
Rabbit_Pos=zeros(1,varNum);
Rabbit=inf; %change this to -inf for maximization problems

Boundary_no= size(upperBound,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle number for both ub and lb
if Boundary_no==1
    Positions=rand(N, varNum).*(upperBound-lowerBound)+lowerBound;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:varNum
        ub_i=upperBound(i);
        lb_i=lowerBound(i);
        Positions(:,i)=rand(N,1).*(ub_i-lb_i)+lb_i;
    end
end
%==============================
%------------- HHO ------------
%==============================
bestSoFar=zeros(1,maxLoop);

% Main loop
for it=1:maxLoop
    
    E1=2*(1-(it/maxLoop)); % factor to show the decreaing energy of rabbit
    
    % Update the location of Harris' hawks
    for i=1:N
        E0=2*rand()-1;  % -1<E0<1
        Escaping_Energy=E1*E0;  % escaping energy of rabbit Eq. (3) in the paper
        
        % -------- Exploration phase Eq. (1) in paper -------------------
        if abs(Escaping_Energy)>=1
            %Harris' hawks perch randomly based on 2 strategy:
            q =rand();
            rand_Hawk_index = floor(N*rand()+1);
%             X_rand = Hawks(rand_Hawk_index).Position;
            X_rand = Positions(rand_Hawk_index,:);
            if q<0.5
                % perch based on other family members
                Positions(i,:)=X_rand-rand()*abs(X_rand-2*rand()*Positions(i,:));
            elseif q>=0.5
                %perch on a random tall tree (random site inside group's home range)
                z=[Positions];
                z=reshape(z,[varNum,N])';
                Positions(i,:)=...
                (Rabbit_Pos - mean(z))-rand().*unifrnd(lowerBound, upperBound);
            end
            % -------- Exploitation phase -------------------
        elseif abs(Escaping_Energy)<1
            %Attacking the rabbit using 4 strategies regarding the behavior of the rabbit
            % phase 1: ----- surprise pounce (seven kills) ----------
            %surprise pounce (seven kills): multiple, short rapid dives by different hawks
            
            r=rand(); % probablity of each event
            
            if r>=0.5 && abs(Escaping_Energy)<0.5 % Hard besiege Eq. (6) in paper
                Positions(i,:)=Rabbit_Pos-...
                Escaping_Energy*abs(Rabbit_Pos-Positions(i,:));
            end
            
            if r>=0.5 && abs(Escaping_Energy)>=0.5  % Soft besiege Eq. (4) in paper
                Jump_strength=2*(1- rand()); % random jump strength of the rabbit
                
                Positions(i,:)=(Rabbit_Pos-Positions(i,:))...
                    -Escaping_Energy*abs(Jump_strength*Rabbit_Pos-Positions(i,:));
            end
            %phase 2: --------performing team rapid dives (leapfrog movements)----------
            
            if r<0.5 && abs(Escaping_Energy)>=0.5 % Soft besiege Eq. (10) in paper
                %rabbit try to escape by many zigzag deceptive motions
                Jump_strength=2*(1-rand());
                Y=Rabbit_Pos-Escaping_Energy*...
                    abs(Jump_strength*Rabbit_Pos-Positions(i,:));
                
                if fitnessfunction(Positions(i,:),Histogram, Thresh_number)< Rabbit % improved move?
                    Positions(i,:) = Y;
                else % hawks perform levy-based short rapid dives around the rabbit
                    Z=Y+rand(1,varNum).*Levy(varNum);
                    
                    if fitnessfunction(Positions(i,:),Histogram, Thresh_number)< Rabbit
                        Positions(i,:) = Z;
                    end
                end
            end
            if r<0.5 && abs(Escaping_Energy)<0.5   % Hard besiege Eq. (11) in paper
                Jump_strength=2*(1-rand());
                pos=[Positions];
                pos=reshape(pos, [varNum, N])';
                
                Y=Rabbit_Pos-Escaping_Energy*...
                    abs(Jump_strength*Rabbit_Pos-mean(pos));
                
                if fitnessfunction(Positions(i,:),Histogram, Thresh_number)< Rabbit% improved move?
                    Positions(i,:) = Y;
                else % Perform levy-based short rapid dives around the rabbit 
                    
                    Z=Y+rand(1,varNum).*Levy(varNum);
                    if fitnessfunction(Positions(i,:),Histogram, Thresh_number)< Rabbit
                        Positions(i,:) = Z;
                    end
                end
            end
        end
        % Check Boundari
        Positions(i,:)=max(Positions(i,:),lowerBound);
        Positions(i,:)=min(Positions(i,:),upperBound);
        
        %calc fitness
        fitness=fitnessfunction(Positions(i,:),Histogram, Thresh_number);
        
        %update global solution
        if fitness<Rabbit
            Rabbit_Pos = Positions(i,:);
            Rabbit=fitness;
        end
    end
    
    bestSoFar(it)=Rabbit;
    
end
Best_Fit=1/Rabbit;

Best_Thresh=Rabbit_Pos;
Best_Thresh=fix(sort(Best_Thresh));
%==============================
%---- Evaluate Performance ----
%==============================
Segment_im=zeros(size(im));

for i=1:Class_number
    if i==1
        Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1)));
    elseif i>1 && i<Class_number
         Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1)));
    elseif i==Class_number
         Segment_im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1)));
    end
end



