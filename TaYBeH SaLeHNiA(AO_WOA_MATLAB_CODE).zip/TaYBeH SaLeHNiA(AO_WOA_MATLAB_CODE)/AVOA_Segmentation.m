function [Best_Fit, Best_Thresh, Segment_im] = AVOA_Segmentation(Histogram, im, Thresh_number, Class_number, pop_size, max_iter, variables_no, CMax, minI, lb, ub)
% AVOA_Segmentation - Robustified and boundary-safe version
% Inputs:
%   Histogram, im, Thresh_number, Class_number,
%   pop_size, max_iter, variables_no, CMax, minI, lb, ub
% Outputs:
%   Best_Fit, Best_Thresh, Segment_im

% initialize Best vultures
Best_vulture1_X = zeros(1,variables_no);
Best_vulture1_F = inf;
Best_vulture2_X = zeros(1,variables_no);
Best_vulture2_F = inf;

avg_fit = zeros(1, max_iter);
sum_fit = zeros(1, max_iter);

% Initialize population (use your initialization function)
X = initialization(pop_size, variables_no, ub, lb);

% Defensive: ensure X shape is pop_size x variables_no
if size(X,1) ~= pop_size || size(X,2) ~= variables_no
    % try to fix or reinitialize uniformly
    X = zeros(pop_size, variables_no);
    for ii=1:variables_no
        X(:,ii) = unifrnd(min(lb,[],'all'), max(ub,[],'all'), [pop_size,1]);
    end
end

% ensure lb/ub vectors
if isscalar(lb), lb = lb * ones(1,variables_no); end
if isscalar(ub), ub = ub * ones(1,variables_no); end

% Initialize Best_P with first individual
Best_P = X(1,:);

% controlling parameters
p1 = 0.6; p2 = 0.4; p3 = 0.6;
alpha = 0.8; betha = 0.2; gamma = 2.5;

current_iter = 0;
Convergence_curve = zeros(1,max_iter);

while current_iter < max_iter
    % Evaluate fitness and update best vultures
    for i = 1:pop_size
        xi = X(i,:);
        current_vulture_F = fitnessfunction(xi, Histogram, Thresh_number);
        % Update best vulture 1 (minimization assumed in your original code)
        if current_vulture_F < Best_vulture1_F
            Best_vulture1_F = current_vulture_F;
            Best_vulture1_X = xi;
            sum_fit(i) = current_vulture_F;
            Best_P = xi;
        end
        % Update second best
        if current_vulture_F > Best_vulture1_F && current_vulture_F < Best_vulture2_F
            Best_vulture2_F = current_vulture_F;
            Best_vulture2_X = xi;
            Best_P = xi;
        end
    end

    % control param a and P1
    a = unifrnd(-2,2,1,1)*((sin((pi/2)*(current_iter/max_iter))^gamma) + cos((pi/2)*(current_iter/max_iter))-1);
    P1 = (2*rand + 1) * (1 - (current_iter/max_iter)) + a;

    % Update the location for each vulture
    for i = 1:pop_size
        current_vulture_X = X(i,:);  % row vector
        F = P1 * (2*rand() - 1);

        % get random vulture reference (ensure row vector)
        random_vulture_X = random_select(Best_vulture1_X, Best_vulture2_X, alpha, betha);
        random_vulture_X = random_vulture_X(:)';

        if abs(F) >= 1
            newX = exploration(X, current_iter, max_iter, pop_size, current_vulture_X, variables_no);
        else
            newX = exploitation(current_vulture_X, Best_vulture1_X, Best_vulture2_X, random_vulture_X, F, p2, p3, variables_no, ub, lb);
        end

        % Normalize newX to be 1 x variables_no
        newX = newX(:)';  % make row
        if numel(newX) > variables_no
            newX = newX(1:variables_no);
        elseif numel(newX) < variables_no
            % pad with uniform randoms within bounds
            padN = variables_no - numel(newX);
            filler = lb(end-padN+1:end) + rand(1,padN).*(ub(end-padN+1:end) - lb(end-padN+1:end));
            newX = [newX, filler];
        end

        % Apply adaptive reflection & clip to bounds
        newX = reflect_and_clip(newX, lb, ub);

        % Final ensure row and correct length
        newX = newX(:)';

        % assign back
        X(i,:) = newX;
    end

    current_iter = current_iter + 1;
    Convergence_curve(current_iter) = Best_vulture1_F;
    avg_fit(current_iter) = mean(sum_fit);

    % Boundary enforcement for entire population (row-wise reflect)
    for i=1:pop_size
        X(i,:) = reflect_and_clip(X(i,:), lb, ub);
    end

    fprintf("In Iteration %d, best estimation of the global optimum is %4.4f \n", current_iter, Best_vulture1_F);
end

% Prepare outputs (guard against inf/zero)
if isinf(Best_vulture1_F) || Best_vulture1_F == 0
    Best_Fit = 0;
else
    Best_Fit = 1 / Best_vulture1_F;
end

Best_Thresh = floor(Best_P);
Best_Thresh = sort(Best_Thresh);

% Build segmented image
Segment_im = zeros(size(im));
edges = [0, Best_Thresh, 256];
for k = 1:Class_number
    a = edges(k);
    b = edges(k+1)-1;
    mask = (im >= a) & (im <= b);
    if any(mask(:))
        Segment_im(mask) = mean(im(mask));
    end
end
zidx = (Segment_im == 0);
if any(zidx(:)), Segment_im(zidx) = im(zidx); end

end

% -------------------- helper: reflect_and_clip ----------------------
function Xr = reflect_and_clip(X, LB, UB)
    % Ensure LB/UB are vectors matching X length
    n = numel(X);
    if isscalar(LB), LB = LB * ones(1,n); end
    if isscalar(UB), UB = UB * ones(1,n); end
    Xr = X;
    for kk = 1:n
        if Xr(kk) > UB(kk)
            Xr(kk) = UB(kk) - (Xr(kk) - UB(kk));
        elseif Xr(kk) < LB(kk)
            Xr(kk) = LB(kk) + (LB(kk) - Xr(kk));
        end
        % final clamp
        if Xr(kk) > UB(kk), Xr(kk) = UB(kk); end
        if Xr(kk) < LB(kk), Xr(kk) = LB(kk); end
    end
end


% Best_Fit=1/Target_score;
% 
% Best_Thresh=Target_pos;
% Best_Thresh=floor(sort(Best_Thresh));
% %==============================
% %---- Evaluate Performance ----
% %==============================
% Segment_im=zeros(size(im));
% 
% for i=1:Class_number
%     if i==1
%         Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1)));
%     elseif i>1 && i<Class_number
%          Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1)));
%     elseif i==Class_number
%          Segment_im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1)));
%     end
% end

