function [Best_Fit, Best_Thresh, Segment_im] = GOA_Segmentation(Histogram, im, Thresh_number, Class_number, SearchAgents_no, Max_iter, dim, CMax, CMin, lb, ub)

f=0.5;
l=1.5;
%==============================
%-------Initialization---------
%==============================
% initialize position vector and score for the leader
Target_pos=zeros(1, dim);
Target_score=inf; %change this to -inf for maximization problems

Boundary_no= size(ub,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle number for both ub and lb
if Boundary_no==1
    Positions=rand(SearchAgents_no, dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        Positions(:,i)=rand(SearchAgents_no,1).*(ub_i-lb_i)+lb_i;
    end
end
%==============================
%------------- GOA ------------
%==============================
Convergence_curve=zeros(1,Max_iter);
it=0;% Loop counter
% Main loop
while it<Max_iter
    for i=1:size(Positions,1)
        
        % Return back the search agents that go beyond the boundaries of the search space
        Flag4ub=Positions(i,:)>ub;
        Flag4lb=Positions(i,:)<lb;
        Positions(i,:)=(Positions(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        
        % Calculate objective function for each search agent
        fitness=fitnessfunction(Positions(i,:),Histogram,Thresh_number);
        
        % Update the leader
        if fitness<Target_score % Change this to > for maximization problem
            Target_score=fitness; % Update alpha
            Target_pos=Positions(i,:);
        end
        
    end
    c=CMax-it*((CMax-CMin)/Max_iter); 
    
    % Update the Position of search agents 
    for i=1:size(Positions,1)
        sum=0;
        d1=(ub- lb)./2;
        c1= c.*d1;
        
        for j=1:size(Positions,2)
            if i~=j
                Dij=norm(Positions(i,:)-Positions(:,j));               
                t= (Positions(:,j)-Positions(i,:))./Dij;
                r=abs(Positions(i,:)-Positions(:,j));
                r=1+rem(r,3);
                S=f.*exp(-r./l)-exp(-r);
                tmp= c1 .*S.*rand().*t;
                sum=sum+tmp;
                Positions(i,j)= c.*sum(i,j)+rand().*Target_pos(j); 
            end
        end
    end
    it=it+1;
    Convergence_curve(it)=Target_score;
end

Best_Fit=1/Target_score;

Best_Thresh=Target_pos;
Best_Thresh=floor(sort(Best_Thresh));
%==============================
%---- Evaluate Performance ----
%==============================
Segment_im=zeros(size(im));

for i=1:Class_number
    if i==1
        Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1)));
    elseif i>1 && i<Class_number
         Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1)));
    elseif i==Class_number
         Segment_im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=CMax,im>=Best_Thresh(i-1))==1)));
    end
end

