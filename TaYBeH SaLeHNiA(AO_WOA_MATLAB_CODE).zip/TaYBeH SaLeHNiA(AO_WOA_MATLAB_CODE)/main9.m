%% ================= IoV+UAV+RSU+Cloud Simulation with G-AliDaei-O (Advanced) =================
clc; clear; close all;

%% ---------------------- Phase 1: System Definition --------------------------
road_length = 3000;  
road_width  = 500;  
dt = 1;              

numVehicles = 120;
numUAVs     = 8;
numRSUs     = 4;
numCloud    = 1;

[Vehicles, UAVs, RSUs, Cloud] = initializeSystem(numVehicles,numUAVs,numRSUs,road_length,road_width);

taskSizes = [1000 2000 4000 6000 8000 10000];
Tasks = cell(length(taskSizes),1);
for i=1:length(taskSizes)
    Tasks{i} = generateTasks(taskSizes(i), Vehicles, UAVs, RSUs, Cloud);
end

%% ---------------------- Phase 2: G-AliDaei-O Optimization -------------------
SearchAgents_no = 50;  
Max_iteration  = 100;  
dim = length(Tasks{1}); 

lb = 1; 
ub = 4;

fobj = @(X) fitnessDetailed(X, Tasks{1}, Vehicles, UAVs, RSUs, Cloud, dt);

[BestFitness, BestPosition, Convergence_curve, ~, ~, ~] = ...
    GAliDaeiO(SearchAgents_no, Max_iteration, lb, ub, dim, fobj);

%% ---------------------- Phase 3: Compute Detailed Metrics -------------------
[delaySum, costSum, loadVar, trustSum, energySum, taskAllocation] = ...
    computeMetrics(BestPosition, Tasks{1}, Vehicles, UAVs, RSUs, Cloud, dt);

disp('--- Best Solution Metrics ---');
disp(['Total Delay          = ', num2str(delaySum)]);
disp(['Total Network Cost   = ', num2str(costSum)]);
disp(['Load Variance        = ', num2str(loadVar)]);
disp(['Total Trust          = ', num2str(trustSum)]);
disp(['Total Energy         = ', num2str(energySum)]);

disp('--- Task Allocation (TaskID -> NodeType_NodeID) ---');
for i=1:length(taskAllocation)
    disp(['Task ', num2str(i), ' -> ', taskAllocation{i}]);
end

%% ---------------------- Phase 4: Plot Metrics -------------------
figure;
bar([delaySum, costSum, loadVar, trustSum, energySum]);
set(gca,'XTickLabel',{'Delay','Cost','LoadVar','Trust','Energy'});
ylabel('Metric Value'); title('Best Solution Metrics');

figure;
plot(Convergence_curve,'LineWidth',2);
xlabel('Iteration'); ylabel('Best Fitness');
title('Convergence Curve');

%% ==================== Supporting Functions ====================

function [delaySum, costSum, loadVar, trustSum, energySum, taskAllocation] = computeMetrics(X, Tasks, Vehicles, UAVs, RSUs, Cloud, dt)
    numTasks = length(Tasks);
    delaySum = 0; costSum = 0; loadVar = 0; trustSum = 0; energySum = 0;
    VehiclesCopy = Vehicles; UAVsCopy = UAVs;
    nodeLoads = containers.Map('KeyType','char','ValueType','any');
    taskAllocation = cell(numTasks,1);
    
    for t=1:numTasks
        task = Tasks(t);
        nodeType = round(X(t));
        
        % Mobility update
        for v=1:length(VehiclesCopy)
            VehiclesCopy(v).x = VehiclesCopy(v).x + VehiclesCopy(v).speed*dt;
        end
        for u=1:length(UAVsCopy)
            theta = rand*2*pi;
            UAVsCopy(u).x = UAVsCopy(u).x + UAVsCopy(u).speed*dt*cos(theta);
            UAVsCopy(u).y = UAVsCopy(u).y + UAVsCopy(u).speed*dt*sin(theta);
        end
        
        % Node selection
        switch nodeType
            case 1, node = VehiclesCopy(randi(length(VehiclesCopy))); nodeID=node.ID;
            case 2, node = UAVsCopy(randi(length(UAVsCopy))); nodeID=node.ID;
            case 3, node = RSUs(randi(length(RSUs))); nodeID=node.ID;
            case 4, node = Cloud; nodeID=1;
        end
        taskAllocation{t} = [num2str(nodeType),'_',num2str(nodeID)];
        
        % Distance & Transmission
        source = VehiclesCopy(task.source);
        d = sqrt((source.x - node.x)^2 + (source.y - node.y)^2);
        conn_window = 5; if nodeType==2, conn_window=node.connection_window; end
        BaseRate = 10; alpha=0.01; transRate = BaseRate/(1+alpha*d);
        compTime = task.size/sum(node.resources.capacity);
        delay = compTime + task.data/transRate;
        
        if delay>task.deadline || delay>conn_window, taskSuccess=0; delay=delay*2; cost=task.data*d;
        else taskSuccess=1; cost=task.data*d; end
        
        key=[num2str(nodeType),'_',num2str(nodeID)];
        if ~isKey(nodeLoads,key), nodeLoads(key)=0; end
        nodeLoads(key)=nodeLoads(key)+task.size;
        
        trust = node.trust; energy = task.size*0.5;
        
        % accumulate
        delaySum=delaySum+delay;
        costSum=costSum+cost;
        trustSum=trustSum+trust*taskSuccess;
        energySum=energySum+energy;
    end
    loads=cell2mat(values(nodeLoads));
    avgLoad=mean(loads); loadVar=sum((loads-avgLoad).^2)/length(loads);
end
