function [Best_Fit, Best_Thresh, Segment_im] = Firfly_Segmentation(Histogram, im, Thresh_number, Class_number, nPop, MaxIt, nVar, VarMax, VarMin, lb, ub)

VarSize=[1 nVar];       % Decision Variables Matrix Size
gamma=1;            % Light Absorption Coefficient

beta0=2;            % Attraction Coefficient Base Value

alpha=0.2;          % Mutation Coefficient

alpha_damp=0.99;    % Mutation Coefficient Damping Ratio

delta=0.05*(VarMax-VarMin);     % Uniform Mutation Range

m=2;

% Initialization

% Empty Firefly Structure
firefly.Position=[];
firefly.Cost=[];

% Initialize Population Array
pop=repmat(firefly,nPop,1);

% Initialize Best Solution Ever Found
BestSol=inf;

Boundary_no= size(ub,2); % numnber of boundaries

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    Positions=rand(nPop, nVar).*(ub-lb)+lb;
    for i=1:nPop
        pop(i).Position=Positions(i, :);
        pop(i).Cost=fitnessfunction(pop(i).Position, Histogram, Thresh_number);
    end
end

% Create Initial Fireflies
% Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);
Leader_pos=zeros(1,nVar);
BestSol=inf;
% Firefly Algorithm Main Loop

for it=1:MaxIt
    
    newpop=pop;
    for i=1:nPop
        for j=1:nPop
            if pop(j).Cost<=pop(i).Cost
                rij=norm(pop(i).Position-pop(j).Position);
                beta=beta0*exp(-gamma*rij^m);
                e=delta*unifrnd(-1,+1,VarSize);
                
                newpop(i).Position=pop(i).Position...
                    +beta*(pop(j).Position-pop(i).Position)...
                    +alpha*e;
                
                newpop(i).Position=max(newpop(i).Position,VarMin);
                newpop(i).Position=min(newpop(i).Position,VarMax);
                
                newpop(i).Cost=fitnessfunction(newpop(i).Position,Histogram,Thresh_number);
                
                if newpop(i).Cost<BestSol
                    BestSol=newpop(i).Cost;
                    Leader_pos = newpop(i).Position;
                end
            end
        end
    end
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol;

    % Damp Mutation Coefficient
    alpha=alpha*alpha_damp;
    
end

Best_Fit=1/BestSol;
% Best_Fit=BestSol;

Best_Thresh=Leader_pos;
Best_Thresh=floor(sort(Best_Thresh));
%==============================
%---- Evaluate Performance ----
%==============================
Segment_im=zeros(size(im));

for i=1:Class_number
    if i==1
        Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=0)==1)));
    elseif i>1 && i<Class_number
         Segment_im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=(Best_Thresh(i)-1),im>=Best_Thresh(i-1))==1)));
    elseif i==Class_number
         Segment_im(find(and(im<=VarMax,im>=Best_Thresh(i-1))==1))=mean(im(find(and(im<=VarMax,im>=Best_Thresh(i-1))==1)));
    end
end

