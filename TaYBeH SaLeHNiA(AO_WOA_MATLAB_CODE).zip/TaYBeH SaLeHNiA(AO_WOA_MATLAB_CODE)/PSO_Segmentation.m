function [Best_Fit, Best_Thresh, Segment_im] = PSO_Segmentation( ...
    Histogram, im, Thresh_number, Class_number, ...
    SearchAgents_no, Max_iter, dim, CMax, CMin, lb, ub)

%====================================================
%        Particle Swarm Optimization for Image Segmentation
%====================================================

%==============================
%------- PSO Parameters ------
%==============================
phi1 = 2.05;
phi2 = 2.05;
phi  = phi1 + phi2;
chi  = 2/(phi-2+sqrt(phi^2-4*phi));

w     = chi;
wdamp = 1;
c1    = chi * phi1;
c2    = chi * phi2;

nPop = SearchAgents_no;

VarSize = [1 dim];
VarMin  = lb;
VarMax  = ub;

VelMax = 0.1 * (VarMax - VarMin);
VelMin = -VelMax;

%==============================
%------- Initialization -------
%==============================
empty_particle.Position=[];
empty_particle.Cost=[];
empty_particle.Velocity=[];
empty_particle.Best.Position=[];
empty_particle.Best.Cost=[];

particle = repmat(empty_particle,nPop,1);

GlobalBest.Cost = inf;

for i=1:nPop

    % Initialize Position
    particle(i).Position = rand(VarSize).*(VarMax-VarMin) + VarMin;

    % Initialize Velocity
    particle(i).Velocity = zeros(VarSize);

    % Evaluation
    particle(i).Cost = fitnessfunction(particle(i).Position,Histogram,Thresh_number);

    % Update Personal Best
    particle(i).Best.Position = particle(i).Position;
    particle(i).Best.Cost     = particle(i).Cost;

    % Update Global Best
    if particle(i).Best.Cost < GlobalBest.Cost
        GlobalBest = particle(i).Best;
    end

end

BestCost = zeros(Max_iter,1);

%==============================
%--------- PSO Main Loop ------
%==============================
for it=1:Max_iter

    for i=1:nPop

        % Update Velocity
        particle(i).Velocity = w*particle(i).Velocity ...
            + c1*rand(VarSize).*(particle(i).Best.Position - particle(i).Position) ...
            + c2*rand(VarSize).*(GlobalBest.Position - particle(i).Position);

        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);

        % Update Position
        particle(i).Position = particle(i).Position + particle(i).Velocity;

        % Velocity Mirror Effect
        IsOutside = (particle(i).Position < VarMin | particle(i).Position > VarMax);
        particle(i).Velocity(IsOutside) = -particle(i).Velocity(IsOutside);

        % Apply Position Limits
        particle(i).Position = max(particle(i).Position,VarMin);
        particle(i).Position = min(particle(i).Position,VarMax);

        % Evaluation
        particle(i).Cost = fitnessfunction(particle(i).Position,Histogram,Thresh_number);

        % Update Personal Best
        if particle(i).Cost < particle(i).Best.Cost

            particle(i).Best.Position = particle(i).Position;
            particle(i).Best.Cost     = particle(i).Cost;

            % Update Global Best
            if particle(i).Best.Cost < GlobalBest.Cost
                GlobalBest = particle(i).Best;
            end
        end

    end

    BestCost(it) = GlobalBest.Cost;
    w = w * wdamp;

end

%==============================
%--------- Final Outputs ------
%==============================
Best_Fit    = 1 / GlobalBest.Cost;
Best_Thresh = GlobalBest.Position;
Best_Thresh = floor(sort(Best_Thresh));

%==============================
%---- Image Segmentation ------
%==============================
Segment_im = zeros(size(im));

for i = 1:Class_number
    if i == 1
        idx = find(im <= (Best_Thresh(i)-1) & im >= 0);
        Segment_im(idx) = mean(im(idx));

    elseif i > 1 && i < Class_number
        idx = find(im <= (Best_Thresh(i)-1) & im >= Best_Thresh(i-1));
        Segment_im(idx) = mean(im(idx));

    elseif i == Class_number
        idx = find(im <= CMax & im >= Best_Thresh(i-1));
        Segment_im(idx) = mean(im(idx));
    end
end

end
